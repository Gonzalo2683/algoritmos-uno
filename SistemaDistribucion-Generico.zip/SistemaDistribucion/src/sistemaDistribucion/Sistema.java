
package sistemaDistribucion;

import TADs.Lista;


public class Sistema {
    Lista listaClientes;
    
    public  Sistema(){
        listaClientes = new Lista();
        
    }
}
